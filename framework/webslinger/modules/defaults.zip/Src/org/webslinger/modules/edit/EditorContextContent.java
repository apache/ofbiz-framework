package org.webslinger.modules.edit;

import java.io.InputStream;
import java.io.IOException;

import org.apache.commons.fileupload.FileItem;

import org.webslinger.servlet.Binary;

public class EditorContextContent extends Binary.AbstractFileItemContent {
    protected final Editor.Context context;

    public EditorContextContent(Editor.Context context) {
        this.context = context;
    }

    protected Editor.Context getContext() {
        return context;
    }

    protected FileItem getFileItem() {
        try {
            try {
                return getContext().getContent();
            } catch (EditorException e) {
                throw e.getCause();
            }
        } catch (Error e) {
            throw e;
        } catch (RuntimeException e) {
            throw e;
        } catch (Throwable t) {
            throw (InternalError) new InternalError(t.getMessage()).initCause(t);
        }
    }

    public long getLastModifiedTime() throws IOException {
        return getContext().getLastModifiedTime();
    }

    public String getContentType() throws IOException {
        return getContext().getContentType();
    }

    public String getContentEncoding() throws IOException {
        return getContext().getContentEncoding();
    }

    public boolean exists() throws IOException {
        return getContext().exists();
    }
}
