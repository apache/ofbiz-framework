package org.webslinger.modules.edit;

public class AttributeValueChangeException extends AttributeException {
    protected final Object oldAttrValue;
    protected final Object newAttrValue;

    public AttributeValueChangeException(String message, String attrName, Object oldAttrValue, Object newAttrValue) {
        super(message, attrName);
        this.oldAttrValue = oldAttrValue;
        this.newAttrValue = newAttrValue;
    }

    public AttributeValueChangeException(String attrName, Object oldAttrValue, Object newAttrValue) {
        super(attrName);
        this.oldAttrValue = oldAttrValue;
        this.newAttrValue = newAttrValue;
    }

    public Object getOldAttrValue() {
        return oldAttrValue;
    }

    public Object getNewAttrValue() {
        return newAttrValue;
    }

    protected void getMessage(StringBuffer sb) {
        sb.append('(').append(getOldAttrValue()).append("->").append(getNewAttrValue()).append(')');
    }
}
