package org.webslinger.modules.edit;

public class AttributeValueException extends AttributeException {
    protected final Object attrValue;

    public AttributeValueException(String message, String attrName, Object attrValue) {
        super(message, attrName);
        this.attrValue = attrValue;
    }

    public AttributeValueException(String attrName, Object attrValue) {
        super(attrName);
        this.attrValue = attrValue;
    }

    public Object getAttrValue() {
        return attrValue;
    }

    protected void getMessage(StringBuffer sb) {
        sb.append('(').append(getAttrValue()).append(')');
    }
}
