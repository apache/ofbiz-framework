package org.webslinger.modules.edit;

import java.io.IOException;

public class EditorException extends IOException {
    public EditorException(String message) {
        super(message);
    }

    public EditorException() {
        super();
    }

    public EditorException(String message, Throwable t) {
        super(message);
        initCause(t);
    }

    public EditorException(Throwable t) {
        super();
        initCause(t);
    }
}

