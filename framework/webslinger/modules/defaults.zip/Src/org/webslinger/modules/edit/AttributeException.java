package org.webslinger.modules.edit;

public class AttributeException extends EditorException {
    protected final String attrName;

    public AttributeException(String message, String attrName) {
        super(message);
        this.attrName = attrName;
    }

    public AttributeException(String attrName) {
        super();
        this.attrName = attrName;
    }

    public String getAttrName() {
        return attrName;
    }

    public String getMessage() {
        StringBuffer sb = new StringBuffer();
        getMessage(sb);
        sb.append(": ").append(super.getMessage());
        return sb.toString();
    }

    protected void getMessage(StringBuffer sb) {
        sb.append(getAttrName());
    }
}
