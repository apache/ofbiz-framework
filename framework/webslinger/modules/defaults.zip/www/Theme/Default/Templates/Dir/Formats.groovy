import java.text.DateFormat
import java.text.DecimalFormat

def context = webslinger.context

context.DateFormat = DateFormat.getDateInstance(DateFormat.LONG)
context.TimeFormat = DateFormat.getTimeInstance(DateFormat.LONG)
context.DateTimeFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.FULL)
context.SizeFormat = new DecimalFormat('0.#K')

return null
