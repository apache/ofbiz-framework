import org.webslinger.collections.CollectionUtil
def context = webslinger.context
def sf = context.sf

def id = context.id

def data = CollectionUtil.get(sf.formData.fields, id)

def fieldConfig = sf.config[id]
if (fieldConfig == null) return null

def list = fieldConfig.list


def macroBody = bsf.lookupBean("MacroBody")
def newFields = []
def shortConfig = [:]
for (subField in list) {
	def newField = [:]
	newField.putAll(subField)
	newField.id = new String("${id}.add.${subField.id}")
	newFields.add(newField)
	shortConfig[subField.id] = newField
}
def newContext = new HashMap(context)
newContext.sf = webslinger.event("/WEB-INF/SpeedForm/Create", [fields: newFields, formData: [:], allParameters: sf.allParameters])
newContext.SFListControlPane = true
newContext.SFListId = id
newContext.sf.config.putAll(shortConfig)
macroBody.render(webslinger, response.writer, null, null, newContext, null)
return null
