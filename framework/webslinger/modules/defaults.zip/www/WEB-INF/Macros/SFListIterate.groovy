import org.webslinger.collections.CollectionUtil
def context = webslinger.context
def sf = context.sf

def id = context.id

def data = CollectionUtil.get(sf.formData.fields, id)
def fieldConfig = sf.config[id]
if (fieldConfig == null) return null

context = [:]
context.putAll(webslinger.context)

def list = fieldConfig.list


def newContext = new HashMap(context)
def index = 0
def macroBody = bsf.lookupBean("MacroBody")
for (item in data) {
	def newFields = []
	def formData = [:]
	def shortConfig = [:]
	for (subField in list) {
		def newField = [:]
		newField.putAll(subField)
		newField.id = "${id}.i${index}.${subField.id}"
		newFields.add(newField)
		shortConfig[subField.id] = newField
	}
	CollectionUtil.set(formData, "fields.${id}.i${index}", item)
	newContext.sf = webslinger.event("/WEB-INF/SpeedForm/Create", [fields: newFields, formData: formData, allParameters: sf.allParameters])
	newContext.SFListControlPane = false
	newContext.SFListId = id
	newContext.SFListIndex = index
	newContext.sf.config.putAll(shortConfig)
	macroBody.render(webslinger, response.writer, null, null, newContext, null)
	index++
}
return null

