import org.webslinger.template.TemplateMacro;

def context = webslinger.context
def templateManager = context.templateManager
def sf = context.sf
def config = sf.config
def errors = sf.errors
def macroBody = bsf.lookupBean("MacroBody")
for (id in sf.fields) {
	def fieldConfig = config[id]
	def label = fieldConfig.label
	errors[id].each {
		def subContext = new HashMap(context)
		subContext.e = [label, it]
	        macroBody.render(templateManager, webslinger, response.writer, new TemplateMacro.Args(new Object[0], null), subContext, null)
	}
}
return null
