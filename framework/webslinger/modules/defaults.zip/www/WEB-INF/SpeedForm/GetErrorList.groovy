def sf = webslinger.context.sf
def config = sf.config
def errors = sf.errors
def errorList = []
for (id in sf.fields) {
	def fieldConfig = config[id]
	def label = fieldConfig.label
	def fieldErrors = errors[id]
	errors[id].each { errorList.add([label, it]) }
}
return errorList
