import org.ofbiz.base.util.UtilValidate
def context = webslinger.context
def field = context.field
def value = context.parameters[field]
if (UtilValidate.isEmpty(value)) return null
def fixedValue = value.replaceAll("[\$, ]", "")
if (UtilValidate.isInteger(fixedValue)) return Double.parseDouble(fixedValue);
if (UtilValidate.isFloat(fixedValue)) return Double.parseDouble(fixedValue);
return value;
