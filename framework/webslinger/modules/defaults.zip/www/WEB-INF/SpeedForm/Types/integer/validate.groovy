def errors = []
if (webslinger.payload != null && !(webslinger.payload instanceof Number) && !(webslinger.payload instanceof String)) errors.add("Not an integer($webslinger.payload)")
return [errors: errors]
