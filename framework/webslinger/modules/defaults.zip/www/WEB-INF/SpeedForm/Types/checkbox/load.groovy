def context = webslinger.context
def field = context.field
def config = context.config
if (!config.multiple) return "on".equals(context.parameters[field]) ? true : false
for (value in context.allParameters[field]) {
    if (value.string == config.value) return [(config.value): true]
}
return null
