import org.ofbiz.base.util.UtilValidate
def context = webslinger.context
def field = context.field
def value = context.parameters[field]
if (UtilValidate.isEmpty(value)) return value;
return UtilValidate.isInteger(value) ? Long.parseLong(value) : value;
