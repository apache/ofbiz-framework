import org.ofbiz.base.util.UtilValidate
def context = webslinger.context
def field = context.field
def value = context.parameters[field]
if (UtilValidate.isEmpty(value)) return value;
def fixedValue = value.replaceAll("[,]", "")
return UtilValidate.isInteger(fixedValue) ? Long.parseLong(fixedValue) : UtilValidate.isFloat(fixedValue) ? Double.parseDouble(fixedValue) : value;
