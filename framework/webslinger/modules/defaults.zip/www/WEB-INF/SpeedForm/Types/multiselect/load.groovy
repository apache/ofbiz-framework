import org.webslinger.collections.CollectionUtil

def params = webslinger.context.parameters
def formData = webslinger.context.sf.formData.fields

CollectionUtil.set(formData, webslinger.context.field, [:])
for (i in params.keySet()) {
	System.err.println("FORMDATA: " + CollectionUtil.get(formData, webslinger.context.field))
	if (i.startsWith(webslinger.context.field)) {
		System.err.println("$i=[" + params[i] + "]")
		CollectionUtil.set(formData, i, params[i])
	}
}

return CollectionUtil.get(formData, webslinger.context.field)
