import java.sql.Time
def errors = []
def value = webslinger.payload
if (!(value instanceof Date)) {
	try {
		value = Time.valueOf((String) value);
	} catch (Exception e) {
		errors.add("Invalid time($webslinger.payload) specified")
	}
}
return [errors: errors]
