import java.sql.Date
def errors = []
def value = webslinger.payload
System.err.println("date:value=$value")
if (!(value instanceof Date) && value != null && value.length() != 0) {
	def parts = value.split("-")
	def year
	if (parts.length == 3) {
		try {
			Date.valueOf(parts[2] + '-' + parts[0] + '-' + parts[1])
			year = parts[0]
		} catch (Exception e) {
			errors.add("Invalid date($webslinger.payload) specified")
		}
	} else {
		parts = value.split("/")
		if (parts.length == 3) {
			try {
				Date.valueOf(parts[0] + '-' + parts[1] + '-' + parts[2])
				year = parts[2]
			} catch (Exception e) {
				errors.add("Invalid date($webslinger.payload) specified")
			}
		}
	}
	if (year != null && year.length() == 2) {
		errors.add("Must enter a 4 digit year($year)")
	}
}
return [errors: errors]
