import java.util.ArrayList

def errors = []
if (!webslinger.context.config.values[webslinger.payload]) errors.add("Invalid value($webslinger.payload) specified")
return [errors: errors]
