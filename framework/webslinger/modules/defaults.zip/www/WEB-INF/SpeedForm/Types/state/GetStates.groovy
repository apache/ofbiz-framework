def context = webslinger.context
def config = context.config
def order = []
def values = [:]
for (state in request.getAttribute("delegator").findByAndCache("GeoAssocAndGeoTo", ["geoIdFrom": config.country, "geoAssocTypeId": "REGIONS", "geoTypeId": "STATE"], ["geoName"])) {
	order.add(state.geoId)
	values[state.geoId] = "$state.geoName ($state.geoId)"
}
context.stateOrder = order
context.stateValues = values
return null
