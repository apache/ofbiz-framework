import java.util.ArrayList
import org.ofbiz.base.util.UtilValidate
def errors = []
if (webslinger.payload != null && !(webslinger.payload instanceof Number) && !(webslinger.payload instanceof String)) errors.add("Not a number($webslinger.payload)")
return [errors: errors]
