import java.util.ArrayList
import org.ofbiz.base.util.UtilValidate
def errors = []
if (webslinger.payload != null && !(webslinger.payload instanceof Number)) errors.add("Not a valid price($webslinger.payload)")
return [errors: errors]
