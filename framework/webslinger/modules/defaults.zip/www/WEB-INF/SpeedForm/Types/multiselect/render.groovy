webslinger.context.order = []
webslinger.context.values = [:]
webslinger.event( webslinger.context.config.loader, webslinger.context)
def context = webslinger.context
System.err.println("context.keySet=" + webslinger.context.keySet())

webslinger.merge("output", request, response, context)

return null;
