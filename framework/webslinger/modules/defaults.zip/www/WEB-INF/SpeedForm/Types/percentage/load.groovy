import org.ofbiz.base.util.UtilValidate
def context = webslinger.context
def field = context.field
def value = context.parameters[field]
if (UtilValidate.isEmpty(value)) return null
if (UtilValidate.isFloat(value)) return 0.01 * Double.parseDouble(value);
return value;
