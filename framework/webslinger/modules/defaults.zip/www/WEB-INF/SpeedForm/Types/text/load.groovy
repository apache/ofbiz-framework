def context = webslinger.context
def field = context.field
def value = context.parameters[field]
if (value == null || value.length() == 0) return value
def config = context.config

if (config.split) {
    def values = value.split(config.split)
    println("values<$values>")
    if (config.trim) values = values.collect{it.trim()}
    return values
}
if (config.trim) value = value.trim()
return value
