import org.webslinger.collections.CollectionUtil

def context = webslinger.context
def config = context.config
def field = context.field
def parameters = context.parameters
def fileParameters = context.fileParameters
def allParameters = context.allParameters
def index = 0

def dataList = CollectionUtil.get(context.sf.formData, "fields.${field}")
def dataMap = new TreeMap()
for (item in dataList) {
	dataMap[index] = item
	index++
}
index = 0
OUTER:
while (true) {
	def isActive = parameters["${field}.active.${index}"]
	if (isActive == null) break
	if (parameters["${field}.delete.${index}"] == "delete") {
		dataMap.remove(index)
		index++
		continue
	}
	def baseId = "${field}.i${index}."
	def newFields = []
	for (subField in config.list) {
		def newField = [:]
		newField.putAll(subField)
		newField.id = new String("${baseId}${subField.id}")
		newFields.add(newField)
	}
	def formData = [:]
	CollectionUtil.set(formData, "fields.${field}.i${index}", dataMap[index])
	def subSf = webslinger.event("/WEB-INF/SpeedForm/Create", [fields: newFields, formData: formData, allParameters: allParameters])
	webslinger.event("/WEB-INF/SpeedForm/Load", [sf: subSf])
	index++
}
dataList = []
index = 0
for (item in dataMap.values()) {
	dataList.add(item)
}
if (parameters["${field}.add"] != null) {
	def baseId = "${field}.add."
	def newFields = []
	for (subField in config.list) {
		def newField = [:]
		newField.putAll(subField)
		newField.id = new String("${baseId}${subField.id}")
		newFields.add(newField)
	}
	def formData = [:]
	def newValue = [:]
	dataList.add(newValue)
	CollectionUtil.set(formData, "fields.${field}.add", newValue)
	def subSf = webslinger.event("/WEB-INF/SpeedForm/Create", [fields: newFields, formData: formData, allParameters: allParameters])
	webslinger.event("/WEB-INF/SpeedForm/Load", [sf: subSf])
}
return dataList
