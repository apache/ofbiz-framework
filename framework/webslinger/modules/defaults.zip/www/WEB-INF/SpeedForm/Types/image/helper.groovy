import java.awt.Rectangle

import org.webslinger.collections.CollectionUtil
import org.webslinger.servlet.Binary
import org.webslinger.ext.image.ConstrainingTransformerFactory
import org.webslinger.ext.image.CroppingTransformerFactory
import org.webslinger.ext.image.ImageDescriptor
import org.webslinger.ext.image.ImageUtils
import org.webslinger.ext.image.ImageConvertingCache
import org.webslinger.ext.image.ImageConvertor
import org.webslinger.ext.image.TypeConvertingTransformerFactory
import org.webslinger.commons.fileupload.CommonsVfsFileItem
import org.webslinger.json.JSONWriter

System.err.println("image helper($webslinger.pathInfo:$webslinger.payload)")
def root = webslinger.webslingerServletContext.container.root

def rawConvertor
def previewCroppingConvertor
def croppingConvertor

def configureCroppers = { fileData ->
	def config = fileData.config
	rawConvertor = new ImageConvertingCache(getClass(), "rawConvertor", null, new ImageConvertor(root.resolveFile("/Var/SpeedForm/image/raw")))
	rawConvertor.getFactories().add(new TypeConvertingTransformerFactory("jpeg"))
	if (config && config.containerWidth && config.containerHeight) {
		rawConvertor.getFactories().add(new ConstrainingTransformerFactory((int) config.containerWidth, (int) config.containerHeight))
	}

	previewCroppingConvertor = new ImageConvertingCache(getClass(), "previewCroppingConvertor", null, new ImageConvertor(root.resolveFile("/Var/SpeedForm/image/preview-crop")))
	previewCroppingConvertor.getFactories().add(new TypeConvertingTransformerFactory("jpeg"))
	previewCroppingConvertor.getFactories().add(new CroppingTransformerFactory(true))
	previewCroppingConvertor.getFactories().add(new ConstrainingTransformerFactory(160, 160))

	croppingConvertor = new ImageConvertingCache(getClass(), "croppingConvertor", null, new ImageConvertor(root.resolveFile("/Var/SpeedForm/image/preview")))
	croppingConvertor.getFactories().add(new TypeConvertingTransformerFactory("jpeg"))
	croppingConvertor.getFactories().add(new CroppingTransformerFactory(false))
	croppingConvertor.getFactories().add(new ConstrainingTransformerFactory(160, 160))

}

def makeImageDescriptor = { fileData ->
	def uploaded = fileData.uploaded
	def config = fileData.config
	if (!(uploaded instanceof CommonsVfsFileItem)) uploaded = webslinger.copyFileItem(uploaded);
	return [
		getFile:		{ uploaded.file },
		getContentEncoding:	{ null },
		getContentType:		{ uploaded.contentType },
		get:	{ prefix, name ->
			switch ("$prefix:$name") {
				case "crop:x":		return fileData.cropX
				case "crop:y":		return fileData.cropY
				case "crop:width":	return fileData.cropWidth
				case "crop:height":	return fileData.cropHeight
				case "crop:enabled":	return config ? (config.croppable ? fileData.cropEnabled : config.cropRatio ? "constrain" : "false") : fileData.cropEnabled
				case "crop:ratio":	return config ? config.cropRatio : fileData.cropRatio
			}
			return null
		}
	] as ImageDescriptor
}

switch (webslinger.pathInfo) {
	case ~/^\/Cropped\/.*/:
		def fileData = CollectionUtil.get(webslinger.context.data.fields, webslinger.pathInfo.substring(9))
		if (fileData == null) {
			response.sendError(404);
			return null
		}
		configureCroppers(fileData)
		def image = makeImageDescriptor(fileData)
		response.addHeader("Cache-Control", "No-Cache")
		response.setHeader("Expires", "-1")
		def dest;
		if (request.getParameter("preview") != null) {
			System.err.println("image preview");
			dest = previewCroppingConvertor.get(image).getObject()
		} else {
			dest = croppingConvertor.get(image).getObject()
		}
		def imageHandler = webslinger.webslingerServletContext.getTypeHandler("image")
		imageHandler.run(image, request, response, dest)
		break;
	case ~/^\/Image\/.*/:
		def fileData = CollectionUtil.get(webslinger.context.data.fields, webslinger.pathInfo.substring(7))
		if (fileData == null) {
			response.sendError(404);
			return null
		}
		configureCroppers(fileData)
		response.addHeader("Cache-Control", "No-Cache")
		response.setHeader("Expires", "-1")
		def image = makeImageDescriptor(fileData)
		def dest
		if (request.getParameter("thumb") == null) {
			dest = rawConvertor.get(image).getObject()
		} else {
			if (request.getParameter("preview") != null) {
				System.err.println("thumb preview");
				dest = previewCroppingConvertor.get(image).getObject()
			} else {
				dest = croppingConvertor.get(image).getObject()
			}
		}
		def imageHandler = webslinger.webslingerServletContext.getTypeHandler("image")
		imageHandler.run(image, request, response, dest)
		break;
	case ~/^\/Cropping\/.*/:
		System.err.println("Cropping")
		def field = webslinger.pathInfo.substring(10)
		webslinger.context.field = field
		def fileData = CollectionUtil.get(webslinger.context.data.fields, field)
		if (fileData == null) {
			response.sendError(404);
			return null
		}
		def image = makeImageDescriptor(fileData)
		def config = fileData.config
		def box = ImageUtils.getImageBox(image.file)
		System.err.println("config=$config")
		def constrainedBox = ImageUtils.constrainBox((int) box.width, (int) box.height, (int) config.containerWidth, (int) config.containerHeight)
		double widthRatio = box.width / constrainedBox.width 
		double heightRatio = box.height / constrainedBox.height
		System.err.println("box=$box")
		System.err.println("constrained=$constrainedBox")
		if (request.getParameter("isJson")) {
			System.err.println("isJson")
			if (request.getParameter("Set") != null) {
				System.err.println("set")
				System.err.println("width/height = $widthRatio/$heightRatio")
				for (name in ["cropX", "cropWidth"]) {
					def pValue = Double.parseDouble(request.getParameter(name));
					def pAdjusted = pValue * widthRatio;
					System.err.println("$name:value=$pValue;adj=$pAdjusted")
					fileData[name] = Double.valueOf(pAdjusted).longValue()
				}
				for (name in ["cropY", "cropHeight"]) {
					def pValue = Double.parseDouble(request.getParameter(name));
					def pAdjusted = pValue * heightRatio;
					System.err.println("$name:value=$pValue;adj=$pAdjusted")
					fileData[name] = Double.valueOf(pAdjusted).longValue()
				}
				fileData.cropEnabled = "true"
			} else if (request.getParameter("Clear") != null) {
				System.err.println("clear")
				fileData.cropEnabled = "false"
			}
			def jsonResult = [
				success:	true,
				hub:		[
					[topic: "sf.image.refresh", data: [id: field]],
				],
			]
			response.setContentType("text/x-json")
			new JSONWriter(response.writer).write(jsonResult)
			return null
		}

		webslinger.context.data = fileData
		//def config = [:]
		//for (name in ["containerHeight", "containerWidth", "dragHeight", "dragWidth"]) {
		//	config[name] = Integer.valueOf(request.getParameter(name))
		//}
		//config.cropRatio = Float.valueOf(request.getParameter("cropRatio"))
		System.err.println("box=$box, constrained=$constrainedBox")

		webslinger.context.imageWidth = (int) constrainedBox.width
		webslinger.context.imageHeight = (int) constrainedBox.height
		webslinger.context.containerWidth = (int) constrainedBox.width + config.dragWidth * 2 + 2
		webslinger.context.containerHeight = (int) constrainedBox.height + config.dragHeight * 2 + 2
		webslinger.context.cropX = fileData.cropX / widthRatio
		webslinger.context.cropWidth = fileData.cropWidth / widthRatio
		webslinger.context.cropY = fileData.cropY / heightRatio
		webslinger.context.cropHeight = fileData.cropHeight / heightRatio
		webslinger.context.config = config
		webslinger.forward("Cropping")
		break;
	case ~/^\/(Crop\.css|Helper\.js)$/:
		webslinger.forward(webslinger.pathInfo.substring(1))
		break;
	default:
		throw new IllegalArgumentException("Unknown pathinfo($webslinger.pathInfo)")
}
return null
