def errors = []
if (webslinger.context.config.dynamic && webslinger.payload == "-NEW-") errors.add("Please select a value")
return [errors: errors]
