def context = webslinger.context
def field = context.field
return "Y".equals(context.parameters[field]) ? true : false
