import java.util.ArrayList
import org.ofbiz.base.util.UtilValidate
def errors = []
if (webslinger.payload != null && !UtilValidate.isZipCode(webslinger.payload)) errors.add("Invalid zipcode($webslinger.payload) specified")
return [errors: errors]
