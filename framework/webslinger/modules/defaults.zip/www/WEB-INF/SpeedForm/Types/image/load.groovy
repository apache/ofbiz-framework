import java.io.File

import org.ofbiz.base.util.UtilValidate

import org.webslinger.ext.image.ImageUtils
import org.webslinger.io.IOUtil
import org.webslinger.commons.fileupload.CommonsVfsFileItem;

def context = webslinger.context
def config = context.config
def processImage = { field ->
	def uploaded = context.fileParameters["${field}.uploaded"]
	def result = [:]
	result.config = config
	if (uploaded?.size > 0) {
		if (!(uploaded instanceof CommonsVfsFileItem)) uploaded = webslinger.copyFileItem(uploaded);
		def imageBox = ImageUtils.getImageBox("speedform-image-type-", uploaded.inputStream)
		if (imageBox != null) {
			result.uploaded = uploaded
			result.imageWidth = (int) imageBox.getWidth()
			result.imageHeight = (int) imageBox.getHeight()
			result.cropEnabled = "false"
		} else {
			context.sf.errors[field].add("Invalid file uploaded")
			result.uploaded = null
		}
	}

	if (config.croppable) {
		def parseNumber = { label ->
			def value = context.parameters["${field}.$label"]
			return value != null && UtilValidate.isFloat(value) ? Float.parseFloat(value).longValue() : -1
		}
		if (uploaded?.size > 0 || context.parameters["${field}.cropX"] == null) {
			//if (result.uploaded) {
				if (result.imageWidth) {
					def imageWidth = result.imageWidth
					def imageHeight = result.imageHeight
					def cropWidth = imageWidth
					def cropHeight = imageHeight
					if (imageWidth > imageHeight) {
						if (config.cropRatio > 1) {
							cropWidth = cropHeight / config.cropRatio
						} else {
							cropHeight = cropWidth / config.cropRatio
						}
					} else {
						if (config.cropRatio > 1) {
							cropHeight = cropWidth * config.cropRatio
						} else {
							cropWidth = cropHeight * config.cropRatio
						}
					}
					result.cropX = (int) ((imageWidth - (cropWidth)) / 2)
					result.cropY = (int) ((imageHeight - (cropHeight)) / 2)
					result.cropWidth = (int) cropWidth
					result.cropHeight = (int) cropHeight
					result.cropEnabled = "true"
				}
			//}
		} else {
			result.cropX = parseNumber("cropX")
			result.cropY = parseNumber("cropY")
			result.cropWidth = parseNumber("cropWidth")
			result.cropHeight = parseNumber("cropHeight")
			result.cropEnabled = "true"
		}
		result.cropRatio = config.cropRatio
	} else if (config.cropRatio) {
		result.cropEnabled = "constrain"
		result.cropRatio = config.cropRatio
	}
	return result

}
def field = context.field
if (config.single) {
	return processImage(field)
} else {
	throw new IllegalArgumentException("multiple not supported")
}
