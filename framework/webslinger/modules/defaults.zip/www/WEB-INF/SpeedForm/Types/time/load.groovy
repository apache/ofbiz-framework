import java.sql.Time

def context = webslinger.context
def field = context.field
def value = context.parameters[field]
if (value == null || value.length() == 0) return value;
def fixed = value.toLowerCase().trim()
int hour, minute, second
boolean isAMPM
boolean isPM
if (fixed =~ /\s*(a|p)m$/) {
	isAMPM = true
	isPM = fixed.charAt(fixed.length() - 2) == 'p'
	fixed = fixed.substring(0, fixed.length() - 2).trim()
} else {
	isAMPM = false;
}
if (fixed =~ /^\d{1,2}$/) {
	hour = Integer.parseInt(fixed)
	minute = 0
	second = 0
} else if (fixed =~ /^\d{1,2}:\\d{2}$/) {
	hour = Integer.parseInt(fixed.substring(0, fixed.length() - 3))
	minute = Integer.parseInt(fixed.substring(fixed.length() - 2))
	second = 0
} else if (fixed =~ /^\d{1,2}:\d{2}:\d{2}$/) {
	hour = Integer.parseInt(fixed.substring(0, fixed.length() - 6))
	minute = Integer.parseInt(fixed.substring(fixed.length() - 5, fixed.length() - 3))
	second = Integer.parseInt(fixed.substring(fixed.length() - 2))
} else {
	return value;
}
if (isAMPM) {
	if (hour > 12 || hour < 1) return value;
	if (isPM) hour += 12;
	if (hour == 24) {
		hour = 12;
	} else if (hour == 12) {
		hour = 0;
	}
} else {
	if (hour > 23 || hour < 0) return value;
}
return Time.valueOf(hour + ":" + minute + ":" + second);
