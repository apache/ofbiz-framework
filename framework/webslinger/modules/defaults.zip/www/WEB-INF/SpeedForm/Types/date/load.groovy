import java.sql.Date

def context = webslinger.context
def field = context.field
def value = context.parameters[field]
if (value == null || value.length() == 0) return value;
def parts = value.split("/")
if (parts.length == 3 && parts[2].length() > 2) {
	return Date.valueOf(parts[2] + '-' + parts[0] + '-' + parts[1])
}
parts = value.split("-")
if (parts.length == 3 && parts[0].length() > 2) {
	return Date.valueOf(parts[0] + '-' + parts[1] + '-' + parts[2])
}
return value
