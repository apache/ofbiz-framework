def context = webslinger.context
def field = context.field
def value = context.parameters[field]
if (value == null || value.length() == 0) return null;
try {
    return Long.parseLong(value)
} catch (NumberFormatException e) {
    return value
}
