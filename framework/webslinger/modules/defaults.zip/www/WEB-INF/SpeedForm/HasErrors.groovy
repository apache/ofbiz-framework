def sf = webslinger.context.sf
def errors = sf.errors
System.err.println("validate()")
for (field in sf.fields) {
	def fieldErrors = errors[field]
	if (fieldErrors != null && !fieldErrors.isEmpty()) return true
}
return false
