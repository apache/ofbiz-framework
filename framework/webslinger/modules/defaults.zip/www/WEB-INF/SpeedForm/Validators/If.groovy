import org.ofbiz.base.util.UtilValidate
def context = webslinger.context
def formConfig = context.formConfig
def parsed = context.parsed
def validatorConfig = context.validatorConfig
def subContext = [:]
subContext.putAll(context)
def isValid = true
OUTER:
def others = validatorConfig.other
if (!others) others = [context.field]
for (other in others) {
	subContext.field = other
	subContext.config = formConfig[other]
	subContext.type = formConfig[other].type
	def data = parsed[other]
	subContext.data = data
	for (validator in validatorConfig.condition) {
		subContext.validatorConfig = validator
		def result = webslinger.event(validator.name, subContext, "validate", data)
		if (result?.errors?.isEmpty()) continue
		isValid = false
		break OUTER
	}

}
def errors = []
if (isValid) {
	subContext.clear()
	subContext.putAll(context)
	def data = context.data
	for (validator in validatorConfig.validators) {
		subContext.validatorConfig = validator
		def result = webslinger.event(validator.name, subContext, "validate", data)
		if (!result?.errors?.isEmpty()) errors.addAll(result.errors)
	}
}
return ["errors":errors]
