import org.webslinger.collections.CollectionUtil

def delegator = webslinger.event("/WEB-INF/Events/GetDelegator")
def fields = webslinger.context.sf.formData.fields
def fieldName = webslinger.context.field

if (webslinger.context.data != null && webslinger.context.data != "" &&
	CollectionUtil.get(fields, fieldName) != webslinger.context.data) {
	def existing = delegator.findByAndCache("UserLogin", [
		userLoginId: webslinger.context.data
		])
	if (existing.size() > 0)
		return ["errors":["""<b>$webslinger.context.config.label</b> is an existing account. <a href="">Click here if you need to change passwords</a>"""]]
} 

return ["errors":[]]
