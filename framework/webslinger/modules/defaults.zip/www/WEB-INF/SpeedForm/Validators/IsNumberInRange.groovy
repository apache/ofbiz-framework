import java.util.ArrayList
import java.util.Arrays
import java.util.Map

import org.webslinger.collections.CollectionUtil

def context = webslinger.context
def value = webslinger.getPayload()
if (value == null)
    return [errors: []]
if (!(value instanceof Number))
    return [errors: ["is not a valid number"]]
def validatorConfig = context.validatorConfig
def low = validatorConfig.low
def high = validatorConfig.high
def errors = []
if (low != null) {
    if (high != null) {
        if (value < low || value > high)
            errors.add("is not in the required range($low .. $high)")
    } else if (value < low)
        errors.add("is too small(must be >= $low)")
} else if (high != null) {
    if (value > high)
        errors.add("is too large(must be <= $high)")
}
return ["errors": errors]
