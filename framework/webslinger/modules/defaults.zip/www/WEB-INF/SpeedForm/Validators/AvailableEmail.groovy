import org.webslinger.collections.CollectionUtil

def delegator = request.getAttribute("delegator")
def context = webslinger.context
def value = webslinger.getPayload()
if (value == null)
    return [:]
def validatorConfig = context.validatorConfig
def originalName = validatorConfig.original
if (originalName) {
	def original = CollectionUtil.get(context.sf.formData.fields, originalName)
	if (original == value.toLowerCase()) return [:]
}
def userLogin = delegator.findByPrimaryKeyCache("UserLogin", [userLoginId: value.toLowerCase()])
if (userLogin == null) return [:]
return [
	errors: ["Email already in use"]
]
