import org.webslinger.servlet.MultipartFormUtil

def context = webslinger.context
def sf = context.sf
System.err.println("parse()")
def parsed = sf.parsed
if (parsed) return parsed
def allParameters = sf.allParameters
parsed = [:]

def searching = sf.searching
def subContext = new HashMap(context)
subContext.allParameters = allParameters
subContext.fileParameters = MultipartFormUtil.filterOutFiles(allParameters)
subContext.parameters = MultipartFormUtil.filterOutStrings(allParameters)
def config = sf.config

def fields
if (context.sfParseOnly) {
	fields = context.sfParseOnly
} else {
	fields = config.keySet()
}
for (name in fields) {
	def fieldConfig = config[name]
    def id = fieldConfig.id
    if (searching) {
        fieldConfig = new HashMap(fieldConfig)
        def searchOverride = fieldConfig.remove('search')
        if (searchOverride) fieldConfig.putAll(searchOverride)
    }
	def type = fieldConfig.type
	def loader = "Types/$type/load"
	if (type != null && webslinger.exists(loader)) {
		subContext.field = id
		subContext.config = fieldConfig
		subContext.formConfig = config
		subContext.type = type
		System.err.println("calling $loader")
		def result = webslinger.event(loader, subContext)
		if (result instanceof Map) {
			for (item in result) {
				parsed["${id}.${item.key}"] = item.value
			}
		} else {
			parsed[id] = result
		}
	} else {
		def values = allParameters[id]
		if (values != null && !values.isEmpty()) {
            if (fieldConfig.multiple) {
                def parsedValues = []
                for (value in values) {
                    parsedValues.add(value.name == null ? value.getString("UTF-8") : value)
                }
                parsed[id] = parsedValues
            } else {
                def fileItem = values[0]
                parsed[id] = fileItem.name == null ? fileItem.getString("UTF-8") : fileItem
            }
		}
	}
}
sf.parsed = parsed
return parsed
