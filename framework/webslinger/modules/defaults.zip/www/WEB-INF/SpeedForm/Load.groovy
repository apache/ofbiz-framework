import org.webslinger.collections.CollectionUtil

Map context = webslinger.getContext();
def sf = context.sf
System.err.println("load()")
def errors = sf.errors
def fields = sf.fields
for (field in sf.fields) {
    errors[field].clear()
}
def parsed = webslinger.event("Parse")
CollectionUtil.expandMap(parsed, sf.formData.fields)
return null
