import java.text.DateFormat
import java.text.DecimalFormat
import org.apache.commons.fileupload.FileItem
import org.webslinger.PathContext
import org.webslinger.container.GivenPathInfo
import org.webslinger.modules.edit.Editor
import org.webslinger.modules.edit.EditorContextContent
import org.webslinger.servlet.MultipartFormUtil

def container = webslinger.webslingerContainer
def fileIcons = webslinger.resolvePath(webslinger.themePath + '/Icons/16x16')
def createPathContext = { file ->
    return new PathContext(container.getFileInfo(file), new GivenPathInfo(""))
}

def createInfo = { name, child, onlyDirs ->
    def pc = createPathContext(child)

    def hasChildren = child.type.hasChildren()
    def icon = pc.getAttribute('icon')
    def title = pc.getAttribute('title')
    def lastModifiedTime
    if (onlyDirs && !hasChildren) return null
    if (hasChildren && icon == null) icon = 'filesystems/folder'
    if (!icon) icon = 'mimetypes/unknown'
    if (!title) title = name
    if (pc.exists()) lastModifiedTime = pc.file.content.lastModifiedTime
    def info = [
        name:           name,
        pc:         pc,
        file:           child,
        icon:           fileIcons.resolve(icon),
        title:          title,
        description:        pc.getAttribute('description'),
        lastModifiedTime:   lastModifiedTime,
    ]
    if (hasChildren) {
        info.iconOpen = fileIcons.resolve(icon + '_open')
        if (child.children.length) info.hasChildren = true
    }
    if (child.type.hasContent) {
        def length = child.content.size
        info.length = length
        info.lengthK = length / 1024
    }
    return info
}

def createChildrenInfo = { target, pc, onlyDirs, subInfo ->
    def file = pc.info.servletFile
    def info = createInfo(file.name.baseName, file, false)
    if (info.hasChildren) {
        def fileSorter = [
            compare:    { left, right ->
                def fixedLeft = left.toLowerCase().replaceAll('[^\\s\\p{Alnum}]', '')
                def fixedRight = right.toLowerCase().replaceAll('[^\\s\\p{Alnum}]', '')
                def r = fixedLeft.compareTo(fixedRight)
                if (r != 0) return r
                return left.compareTo(right)
            }
        ] as Comparator
        def sortedChildren = new TreeMap(fileSorter)
        sortedChildren.putAll(webslinger.getImmediateChildren(file, false))
        def index = sortedChildren.remove('index')
        if (index) info.index = index
        def it = sortedChildren.entrySet().iterator()
        def children = new TreeMap();
        def page = target.request.getParameter('p')
        page = page == null ? 0 : Integer.parseInt(page)
        def length = target.request.getParameter('l')
        length = length == null ? 10 : Integer.parseInt(length)
        def count = length, skip = page * length

        while (count && it.hasNext()) {
            def child = it.next()
            if (skip > 0) {
                skip--
                continue
            }
            def childInfo = createInfo(child.key, child.value[0], onlyDirs)
            if (childInfo == null) {
                it.remove()
            } else {
                children[child.key] = childInfo
            }
            count--
        }
        if (subInfo) children[subInfo.name] = subInfo
        info.children = children
        def pages = []
        for (i in 0 .. (sortedChildren.size() / length)) {
            pages.add(i)
        }
        info.page = page
        info.pages = pages
        info.totalChildren = sortedChildren.size()
        if (page > 0) info.prev = page - 1
        info.length = length
        if (it.hasNext()) info.next = page + 1
    }
    return info
}
switch (webslinger.command) {
    case "init":
        return null
    case "destroy":
        return null
}
/*
def tcontext = target.context
tcontext.DateFormat = DateFormat.getDateInstance(DateFormat.LONG)
tcontext.TimeFormat = DateFormat.getTimeInstance(DateFormat.LONG)
tcontext.DateTimeFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.FULL)
tcontext.SizeFormat = new DecimalFormat('0.#K')
*/
def context = webslinger.context

switch (webslinger.command) {
    case "children":
        def target = webslinger.payload
        def targetPC = target.pathContext
        return createChildrenInfo(target, targetPC, false, null)
    case "action":
        def target = webslinger.payload
        def layout = target.getAttribute("layout")
		def allParameters = MultipartFormUtil.parseRequestAsMap(request)
		def fileParameters = MultipartFormUtil.filterOutFiles(allParameters)
		def parameters = MultipartFormUtil.filterOutStrings(allParameters)
		def path = target.servletPath
		def base = webslinger.webslingerServletContext.getWWW()
		def data = Editor.getEditor(webslinger, base, "")
		def allItems = []

		def baseName
		if (parameters['Action.Delete'] != null) {
			baseName = parameters.Name
			allItems.add(MultipartFormUtil.createStringItem("delete", true, ""))
		} else if (parameters['Action.CreateFile'] != null) {
			baseName = (String) parameters.get("CreateFile.Name")
			allItems.add(MultipartFormUtil.createStringItem("save", true, ""))
			allItems.add(MultipartFormUtil.createStringItem("content", true, ""))
		} else if (parameters['Action.CreateFolder'] != null) {
			baseName = (String) parameters.get("CreateFolder.Name") + "/index.whtml"
			allItems.add(MultipartFormUtil.createStringItem("save", true, ""))
			allItems.add(MultipartFormUtil.createStringItem("content", true, "Please edit me."))
			allItems.add(MultipartFormUtil.createStringItem("attr.template", true, "Dir"))
		} else if (parameters['Action.Upload'] != null) {
			allItems.add(MultipartFormUtil.createStringItem("save", true, ""))
			allItems.add(MultipartFormUtil.createStringItem("upload", true, ""))
			def file = fileParameters["Upload.File"]
			allItems.add(MultipartFormUtil.copyFileItem(file, "file"))
			baseName = (String) parameters.get("Upload.Name")
			if (baseName == null || baseName.length() == 0) baseName = file.name
			/*
			webslinger.event(webslinger.themePath + '/YumDirectoryLister/GlobalActions/Upload', 'action', allParameters)
			if (layout == 'Video')
				webslinger.event(webslinger.themePath+'/YumDirectoryLister/GlobalActions/PostVideoUpload', [
					parameters: allParameters,
					targetFile: targetFile,
					base: context.Base
				])
			*/
		} else if (parameters.rename != null) {
			System.err.println('rename save')
			def renameFrom = webslinger.webslingerServletContext.getFile(parameters.path)
			def renameTo = renameFrom.parent.resolveFile(parameters.content)
			if (renameFrom != renameTo) {
				renameFrom.moveTo(renameTo)
				renameFrom.delete()
			}
			return null
		} else {
			return null
		}
		def fileName = path + "/" + baseName
		Editor.Request req = data.parseRequest(fileName, allItems)
		def errors = context["Errors"]
		data.processRequest(req, errors)

		context.extra = 'id="TrainingTree" class="Tree"'
		context.setState = true
}

return null
