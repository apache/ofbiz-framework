import java.util.Collection
import javax.mail.Address
import javax.mail.Message
import javax.mail.Session
import javax.mail.Transport
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeMessage

if (webslinger.exists("/WEB-INF/Events/System/SetEmail")) webslinger.event("/WEB-INF/Events/System/SetEmail")
System.err.println("context=" + webslinger.context)

def parseEmailAddress;
parseEmailAddress = { address ->
	if (address instanceof Address) return address
	if (address instanceof Collection) {
		def result = []
		for (givenAddress in address) {
			givenAddress = parseEmailAddress(givenAddress)
			if (!givenAddress) continue
			if (givenAddress instanceof Collection) {
				result.addAll(givenAddress)
			} else {
				result.add(givenAddress)
			}
		}
		return result
	}
	return new InternetAddress(address)
}
def context = webslinger.context

def emailData = webslinger.event("/Login/Emails/ForgotPassword", "get-multipart")

def body = context.body
if (!body) body = emailData.body

def headers = [subject: "No subject given"]
headers.putAll(emailData.headers)
if (context.headers) {
	for (headerEntry in context.headers) {
		headers.put(headerEntry.key.toLowerCase(), headerEntry.value)
	}
}
if (context.subject) headers.subject = context.subject

def to = parseEmailAddress(context.toEmailAddress)
def from = parseEmailAddress(context.fromEmailAddress)

def props = System.getProperties()
def smtpHost = webslinger.getConfigString("mail.smtp.host")
if (!smtpHost) smtpHost = "localhost"
props["mail.smtp.host"] = smtpHost
def session = Session.getInstance(props)
def mail = new MimeMessage(session);
mail.setFrom(from);
for (headerEntry in headers) {
	if (headerEntry.key == 'subject') continue
	mail.setHeader(headerEntry.key, headerEntry.value)
}
mail.setSubject(headers.subject, "UTF-8");
mail.setHeader("X-Mailer", webslinger.getConfigString("X-Mailer"));
mail.setSentDate(new Date());
//mail.addRecipients(Message.RecipientType.TO, new InternetAddress("Adam Heath <doogie@brainfood.com>"))
mail.addRecipients(Message.RecipientType.TO, to);
mail.setContent(body)
context.mail = mail
if (webslinger.exists("/WEB-INF/Events/System/RecordEmail")) webslinger.event("/WEB-INF/Events/System/RecordEmail")

def overrideSendToAddresses = webslinger.getConfigStringSplit("mail.smtp.to")
def sendToAddresses
if (overrideSendToAddresses) {
	sendToAddresses = []
	for (overrideAddress in overrideSendToAddresses) {
		if (overrideAddress instanceof Address) {
			sendToAddresses.add(overrideAddress);
		} else if (overrideAddress instanceof String) {
			sendToAddresses.add(new InternetAddress(overrideAddress))
		}
	}
	sendToAddresses = sendToAddresses.toArray(new Address[sendToAddresses.size()])
} else {
	sendToAddresses = mail.getAllRecipients()
}

if ("true".equals(webslinger.getConfigString("mail.enabled"))) {
	Transport transport = session.getTransport("smtp")
	transport.connect()
	transport.sendMessage(mail, sendToAddresses)
	transport.close()
}
return null
