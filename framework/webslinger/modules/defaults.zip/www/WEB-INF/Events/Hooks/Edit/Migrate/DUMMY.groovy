// dummy file so mercurial keeps the directory around.
return null
