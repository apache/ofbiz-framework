import javax.activation.DataHandler
import javax.activation.DataSource
import javax.mail.BodyPart
import javax.mail.MessagingException
import javax.mail.Multipart
import javax.mail.Session
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart
import javax.xml.parsers.ParserConfigurationException
import org.w3c.dom.Element


import org.apache.commons.lang.StringUtils

def target = webslinger.payload
def targetCommand = target.command
def targetContext = target.context

System.err.println("email($targetCommand)")
def emailData;
def file = target.currentFile
if (!file.type.hasChildren) throw new IllegalArgumentException("Not a folder")
def attachmentsDir = file.resolveFile("attachments")
def headersDir = file.resolveFile("headers")
def setEmailData = {
	if (emailData) return emailData

	def html = target.resolvePath("html")
	def text = target.resolvePath("text")

	emailData = [body: new LinkedHashMap()]

	attachmentsDir.close();
	if (attachmentsDir.type.hasChildren()) {
		def attachments = [:]
		for (attachment in attachmentsDir.children) {
			def name = attachment.name.baseName
			def period = name.lastIndexOf(".")
			attachments[name] = name
			if (period != -1) attachments[name.substring(0, period)] = name
		}
		emailData.attachments = attachments
	}

	headersDir.close();
	if (headersDir.type.hasChildren()) {
		def headers = [:]
		for (header in headersDir.children) {
			def name = header.name.baseName
			def period = name.lastIndexOf(".")
			if (period == -1) continue
			name = name.substring(0, period)
			if (name.length() == 0) continue
			def value = StringUtils.chomp(target.capturePath("headers/$name"))
			if (value) headers[name.toLowerCase()] = value
		}
		emailData.headers = headers
	} else {
		emailData.headers = [:]
	}

	if (text.exists()) emailData.body["text/plain"] = text
	if (html.exists()) emailData.body["text/html"] = html

	System.err.println("email=$emailData")
	targetContext.emailData = emailData
	targetContext.usedAttachments = [:]
	targetContext.emailCommand = targetCommand
	return emailData
}
switch (targetCommand) {
	case "merge":
		break;
	case "forward":
		def prefix = target.servletPath
		if (!prefix.endsWith("/")) prefix += "/"
		targetContext.previewPrefix = prefix
		response.setContentType("text/html")
		setEmailData()
		webslinger.forward("View", targetContext)
		break;
	case "include":
		break;
	case "get-multipart":
		setEmailData()
		def mailBody = new MimeMultipart("related")
		def alternativeBody = new MimeMultipart("alternative")
		def foo = new MimeBodyPart()
		foo.setContent(alternativeBody);
		mailBody.addBodyPart(foo)
		for (bodyPart in emailData.body) {
			def value = target.capturePath(bodyPart.value)
			def part = new MimeBodyPart()
			def contentType = bodyPart.key
			part.setDataHandler(new DataHandler([
				getContentType:	{ contentType },
				getInputStream: { new ByteArrayInputStream(value.bytes) },
				getName:	{ new String("content:$value") },
			] as DataSource))
			alternativeBody.addBodyPart(part)
		}
		for (attachment in targetContext.usedAttachments) {
			def name = attachment.key
			def id = attachment.value
			def afile = attachmentsDir.resolveFile(name)
			def contentType = webslinger.resolvePath("attachments/$name").getAttribute("content-type")
			def part = new MimeBodyPart()
			part.setContentID(id)
			part.setDataHandler(new DataHandler([
				getContentType:	{ contentType },
				getInputStream: { afile.content.inputStream },
				getName:	{ new String("file[$name]") },
			] as DataSource))
			mailBody.addBodyPart(part)
		}
		return [body: mailBody, headers: emailData.headers]
		/*
		def message = new MimeMessage(Session.getInstance(System.getProperties()))
		message.setContent(mailBody)
		message.saveChanges();
		def baos = new ByteArrayOutputStream()
		message.writeTo(baos)
		System.err.println("mailBody=$baos")
		*/
		break;
	default:
		throw new IllegalArgumentException("unknown command($targetCommand on $target)");
}
