Editor.config.types["image"] = {
	dragWidth:	8,
	dragHeight:	8,
};
Editor.types["image"] = function(editor, config) {
	var inputX = editor.values['cropX'];
	var inputY = editor.values['cropY'];
	var inputWidth = editor.values['cropWidth'];
	var inputHeight = editor.values['cropHeight'];
	var container = jQuery("#crop");
	// TODO: add listener to detect changes, using constrainUpdate
	var cropView = container.find(".cropView");
	var cropEnabled = jQuery(editor.form).find("input[@name='attr.cropEnabled']");
	var cropEnabledTrue = cropEnabled.filter("*[@value='true']");
	var cropEnabledFalse = cropEnabled.filter("*[@value='false']");
	var cropEnableChecker = function () {
		if (cropEnabledTrue.get(0).checked) cropView.show();
		if (cropEnabledFalse.get(0).checked) cropView.hide();
	};
	cropEnabled.change(cropEnableChecker);
	cropEnableChecker();
	var offsetDisplay = container.find(".cropOffsetDisplay");
	var sizeDisplay = container.find(".cropSizeDisplay");
	var activityItems = jQuery([offsetDisplay.get(0), sizeDisplay.get(0)]);
	activityItems.hide();
	var img = container.find(".cropImage");
	var resizeUpdate = function(size, position) {
		var x = position.left - config.dragWidth;
		var y = position.top - config.dragHeight;
		img.css("left", '-' + x + 'px')
		   .css("top", '-' + y + 'px');
		inputX.value = x;
		inputY.value = y;
		inputWidth.value = size.width;
		inputHeight.value = size.height;
		offsetDisplay.css("top", "0px");
		sizeDisplay.css("bottom", "0px");
	};
	var constrainUpdate = function() {
		var position = {
			left: Math.max(Math.min(inputX.value, config.imageWidth), 0) + config.dragWidth,
			top: Math.max(Math.min(inputY.value, config.imageHeight), 0) + config.dragHeight,
		};
		var size = {
			width: Math.max(Math.min(inputWidth.value, config.imageWidth - position.left), 0),
			height: Math.max(Math.min(inputHeight.value, config.imageHeight - position.top), 0),
		};
		cropView.css("left", position.left + "px")
			.css("top", position.top + "px")
			.css("width", size.width + "px")
			.css("height", size.height + "px");
		resizeUpdate(size, position);
	};
	var toggleActivity = function() {
		activityItems.toggle();
	};
	constrainUpdate();
	cropView.Resizable(
		{
			ratio:		config.ratio,
			minWidth:	config.minWidth,
			minHeight:	config.minHeight,
			maxWidth:	config.imageWidth,
			maxHeight:	config.imageHeight,
			minTop:		config.dragWidth,
			minLeft:	config.dragHeight,
			maxRight:	config.imageWidth + config.dragWidth,
			maxBottom:	config.imageHeight + config.dragHeight,
			dragHandle:	true,
			onDrag:		function(left, top) {
				resizeUpdate({width: inputWidth.value, height: inputHeight.value}, {left: left, top: top});
			},
			onDragStart:	toggleActivity,
			onDragStop:	toggleActivity,
			onStart:	toggleActivity,
			onStop:		toggleActivity,
			handlers: {
				se: ".cropHandleSE",
				e: ".cropHandleE",
				ne: ".cropHandleNE",
				n: ".cropHandleN",
				nw: ".cropHandleNW",
				w: ".cropHandleW",
				sw: ".cropHandleSW",
				s: ".cropHandleS",
			},
			onResize:	resizeUpdate
		}
	);
};
