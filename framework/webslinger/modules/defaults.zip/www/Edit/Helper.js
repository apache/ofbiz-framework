function Editor(path, type) {
	var thiz = this;
	this.path = path;
	this.type = type;
	this.addRow = $("tr[@id='EDIT:ADD:" + path + "']").get(0);
	this.attrTBody = $("tbody[@id='EDIT:ATTRIBUTES:" + path + "']").get(0);
	var form = $("form[@id='EDIT:" + path + "']").get(0);
	this.form = form;
	form.editor = this;
	this.modCount = 0;
	var dispatchers = [
		"addAttribute",
		"deleteAttribute",
		"undeleteAttribute",
		"changeAttribute",
	];
	for (var i = 0; i < dispatchers.length; i++) {
		var dispatcher = dispatchers[i];
		Editor[dispatcher] = function(e) {
			form.editor[dispatcher](e);
		}
	}
	this.deleted = {};
	this.deleteButtons = {};
	this.original = {};
	this.values = {};
	var attrNameElement;
	var attrValueElement;
	for (var i = 0; i < form.length; i++) {
		var element = form.elements[i];
		var elementType = element.getAttribute("type");
		if (elementType == "checkbox" || elementType == "radio") continue;
		if (element.name == "delete") {
			this.deleted[element.value] = element;
		} else if (element.name.substring(0, 5) == "attr.") {
			var attrName = element.name.substring(5);
			//alert("found attribute(" + attrName + ")");
			this.values[attrName] = element;
			this.original[attrName] = element.getAttribute("original");
			var f = function() {
				thiz.checkChanged(arguments.callee.attrName);
				thiz.checkModCount();
			}
			f.attrName = attrName;
			jQuery(element).change(f);
		} else if (element.name.substring(0, 7) == "delete.") {
			var attrName = element.name.substring(7);
			this.deleteButtons[attrName] = element;
			var deleter = function() {
				var attrName = arguments.callee.attrName;
				thiz.deleteAttribute(attrName);
				thiz.checkModCount();
				this.name = "undelete." + attrName;
				this.value = "Undelete";
				return false;
			};
			deleter.attrName = attrName;
			var undeleter = function() {
				var attrName = arguments.callee.attrName;
				thiz.undeleteAttribute(attrName);
				thiz.checkModCount();
				this.name = "delete." + attrName;
				this.value = "Delete";
				return false;
			};
			undeleter.attrName = attrName;
			jQuery(element).toggle(deleter, undeleter);
		} else if (element.name == "attrName") {
			attrNameElement = element;
		} else if (element.name == "attrValue") {
			attrValueElement = element;
		} else if (element.name == "add") {
			jQuery(element).click(function() {
				var attrName = attrNameElement.value;
				if (!attrName) return false;
				var attrValue = attrValueElement.value;
				thiz.setAttribute(attrName, attrValue);
				attrNameElement.value = "";
				attrValueElement.value = "";
				return false;
			});
		}
	}
	if (Editor.types[type]) { 
		this.typeHandler = new Editor.types[type](this, Editor.config.types[type]);
	}
	//alert("Editor created for: " + form);
}

Editor.prototype.setAttribute = function(attrName, attrValue) {
	//alert("addAttribute(" + attrName + ", " + attrValue + ")");
	var form = this.form;
	var valueElement = this.values[attrName];
	var thiz = this;
	if (!valueElement) {
		//alert("new");
		var tr = document.createElement("tr");
		var td = document.createElement("td");
		td.appendChild(document.createTextNode(attrName));
		tr.appendChild(td);
		
		td = document.createElement("td");
		var input = document.createElement("input");
		this.values[attrName] = input;
		input.setAttribute("name", "attr." + attrName);
		input.setAttribute("value", attrValue);
		td.appendChild(input);
		tr.appendChild(td);
		
		td = document.createElement("td");
		input = document.createElement("input");
		input.setAttribute("name", "delete." + attrName);
		input.setAttribute("value", "Delete");
		input.setAttribute("class", "button");
		input.setAttribute("type", "submit");

		this.deleteButtons[attrName] = input;
		var deleter = function() {
			thiz.deleteAttribute(attrName);
			thiz.checkModCount();
			this.name = "undelete." + attrName;
			this.value = "Undelete";
			return false;
		};
		var undeleter = function() {
			thiz.undeleteAttribute(attrName);
			thiz.checkModCount();
			this.name = "delete." + attrName;
			this.value = "Delete";
			return false;
		};
		jQuery(input).toggle(deleter, undeleter);

		td.appendChild(input);
		tr.appendChild(td);

		this.attrTBody.insertBefore(tr, this.addRow);
		this.modCount++;
	} else {
		if (valueElement.disabled) {
			//alert("undelete");
			this.deleteButtons[attrName].click();
		} else {
			//alert("existing");
		}
		// set existing
		valueElement.value = attrValue;
		this.checkChanged(attrName);
	}
	form["attrName"].value = "";
	form["attrValue"].value = "";
	this.checkModCount();
	return false;
}

Editor.prototype.checkModCount = function() {
	this.form.setAttribute("modCount", this.modCount);
	//alert("modCount=" + this.modCount);
	if (this.modCount > 0) {
		$(this.form).addClass("editor-modified");
	} else {
		$(this.form).removeClass("editor-modified");
	}
}

Editor.prototype.checkChanged = function(attrName) {
	//alert("checkChanged(" + attrName + ")");
	var input = this.values[attrName];
	var original = this.original[attrName];
	//alert("checkChanged(" + attrName + "){" + input.value + "<=>" + original + "}");
	if (input.getAttribute("is-changed")) {
		if (input.value == original) {
			this.modCount--;
			input.removeAttribute("is-changed");
		}
	} else {
		if (original != undefined && input.value != original) {
			this.modCount++;
			input.setAttribute("is-changed", true);
		}
	}
}

Editor.prototype.deleteAttribute = function(attrName) {
	var form = this.form;
	//alert("delete(" + attrName + ")");
	if (this.deleted[attrName]) return;
	if (this.original[attrName]) {
		this.modCount++;
		var deleted = document.createElement("input");
		deleted.setAttribute("name", "delete." + attrName);
		deleted.setAttribute("value", "Delete");
		deleted.setAttribute("type", "hidden");
		this.deleted[attrName] = deleted;
		this.form.appendChild(deleted);
	} else {
		this.modCount--;
	}
	this.values[attrName].disabled = true;
	return false;
}

Editor.prototype.undeleteAttribute = function(attrName) {
	var form = this.form;
	//alert("undelete(" + attrName + ")");
	if (this.original[attrName]) {
		this.modCount--;
		this.deleted[attrName].parentNode.removeChild(this.deleted[attrName]);
		delete this.deleted[attrName];
	} else {
		this.modCount++;
	}
	this.values[attrName].disabled = false;
	return false;
}

Editor.types = {};
Editor.config = {
	types: {},
};
