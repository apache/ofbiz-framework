(function() {
 var timer;
 var idToCheck;
 var oldReady = jQuery.ready;
 var newReady = function() {
  if (!idToCheck) return;
  if (timer) clearInterval(timer);
  if (jQuery("#" + idToCheck).get(0) != null) {
   jQuery.isReady = true;
   jQuery.ready = oldReady;
   jQuery.ready();
   return;
  }
  timer = setInterval(newReady, 10);
 };
 jQuery.domLoadPoller = function(id) {
  if (idToCheck) {
   alert("idToCheck already set to(" + idToCheck + "), tried to set it to(" + id + ")");
   return;
  }
  idToCheck = id;
  jQuery.ready = newReady;
  if (timer) clearInterval(timer);
  timer = setInterval(newReady, 10);
 };
})();
