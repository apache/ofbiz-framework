var webslinger;
(function() {
	webslinger = function(path) {
		if (window == this) return new webslinger(path);
		if (path && path[path.length - 1] != '/') path += '/';
		this._path = path;
	};

	function indentingString(doSpace, doNewline) {
		var parts = []
		if (doSpace == null) doSpace = true;
		if (doNewline == null) doNewline = true;
		var lastWasNewline = false;
		var indent = '';
	
		this.newline = function() {
			lastWasNewline = true;
			if (doNewline) parts.push('\n');
			return this;
		};

		checkAfterNewline = function() {
			if (!lastWasNewline) return;
			if (doSpace) {
				parts.push(doNewline ? indent : ' ');
			}
			lastWasNewline = false;
		};

		this.push = function() {
			indent += ' ';
			return this;
		};

		this.pop = function() {
			indent = indent.substring(0, indent.length - 1);
			return this;
		};

		this.space = function() {
			checkAfterNewline();
			if (doSpace) parts.push(' ');
			return this;
		};

		this.write = function(s) {
			var i;
			var offset;
			checkAfterNewline();
			for (i = 0, offset = 0; i < s.length; i++) {
				var c = s.charAt(i);
				parts.push(c);
				if (s.charCodeAt(i) == '\n') {
					checkAfterNewline();
					lastWasNewline = true;
				}
			}
			return this;
		};

		this.toString = function() {
			return parts.join('');
		};
	};

	var writeString = function(o, s) {
		s.write('"');
		for (var i = 0; i < o.length; i++) {
			var c = o.substring(i, i + 1);
			switch (c) {
				case "\\": s.write("\\\\"); continue;
				case "/": s.write("\\/"); continue;
				case "\"": s.write("\\\""); continue;
				case "\b": s.write("\\b"); continue;
				case "\f": s.write("\\f"); continue;
				case "\n": s.write("\\n"); continue;
				case "\r": s.write("\\r"); continue;
				case "\t": s.write("\\t"); continue;
			}
			var code = o.charCodeAt(i);
			if (32 <= code && code >= 256) {
				s.write("\\u");
				var n = Integer.toString(code, 16);
				for (var j = 4 - n.length; j > 0; j--) s.write("0");
				s.write(n);
			} else {
				s.write(c);
			}
  		}
		s.write('"');
	};

	var writeArray = function(o, s) {
		s.write('[').push();
		if (o.length) s.newline();
		for (var i = 0; i < o.length; i++) {
			writeObject(o[i], s);
			if (i != o.length - 1) s.write(',');
			s.newline();
		}
		s.pop().write(']');
	};

	var writeMap = function(o, s) {
		s.write('{').push();
		var i = 0;
		for (var n in o) {
			if (i == 0) {
				s.newline();
			} else {
				s.write(',').newline();
			}
			writeObject(n, s);
			s.write(':').space();
			writeObject(o[n], s);
			i++;
		}
		if (i != 0) s.write(',').newline();
		s.pop().write('}');
	};

	var writeObject = function(o, s) {
		if (o == null) {
			s.write("null");
		} else if (typeof o == 'string') {
			writeString(o, s);
		} else if (o.constructor == Array) {
			writeArray(o, s);
		} else if (typeof o == 'object') {
			writeMap(o, s);
		} else {
			s.write("" + o);
		}
	};

	webslinger.toJSON = function(o) {
		var s = new indentingString();
		writeObject(o, s);
		return s.toString();
	};

	webslinger.defaultErrorHandler = null;

	webslinger.ajax = function(path, payload, context, callback, errorHandler) {
		var args = [];
		for (var i = 0; i < arguments.length; i++) args.push(arguments[i]);
		path = args.shift();
		callback = args.pop();
		if (args[args.length - 1] instanceof Function) {
			errorHandler = callback;
			callback = args.pop();
		} else {
			if (webslinger.defaultErrorHandler) {
				errorHandler = webslinger.defaultErrorHandler;
			} else {
				errorHandler = function(type, data) {
					switch (type) {
						case "request":
							alert("error(" + data.path + ")[" + data.type + "][" + data.exc + "]");
							callback(null, {type: "request", ajax: data});
							break;
						case "client":
							alert("client error(" + data + ")");
							callback(null, {type: "client", exc: data});
							break;
						case "server":
							alert("server error");
							callback(null, {type: "server", error: data});
							break;
					}
				};
			}
		}
		if (args.length == 2) {
			if (args[0] instanceof String) {
				payload = args.shift();
				context = args.shift();
			} else if (args[0] instanceof Object) {
				context = args.shift();
				payload = args.shift();
			} else {
				payload = null;
				context = null;
			}
		} else if (args.length == 1) {
			if (args[0] instanceof String) {
				payload = args.shift();
				context = null;
			} else if (args[0] instanceof Object) {
				context = args.shift();
				payload = null;
			} else {
				payload = null;
				context = null;
			}
		} else {
			payload = null;
			context = null;
		}
		if (path.substring(0, 1) != '/') {
			path = (this._path ? this._path + (this._path[this._path.length - 1] == '/' ? '' : '/')  : '/') + path;
		}
		if (!context) context = {};
		var data = {
			payload: payload,
			context: context
		};
		return {
			async:		true,
			contentType:	"text/x-json",
			data:		writeObject(data),
			dataType:	"json",
			error:		function(req, type, exc) {
				//alert("error(" + path + ")[" + type + "][" + exc + "]");
				errorHandler("request", {path: path, req: req, type: type, exc: exc});
			},
			processData:	false,
			success:	function(data) {
				//alert("success(" + path + "):" + data);
				if (data.hub) {
					for (var i = 0; i < data.hub.length; i++) {
						var item = data.hub[i];
						OpenAjax.hub.publish(item.topic, item.data);
					}
				}
				if (data.result != null) {
					try {
						callback(data.result);
					} catch (e) {
						errorHandler("client", e);
					}
				} else {
					errorHandler("server", data.error);
				}
			},
			type:		"POST",
			url:		path
		};
	};
	webslinger.event = function() {
		var args = [];
		for (var i = 0; i < arguments.length; i++) args.push(arguments[i]);
		jQuery.ajax(webslinger.ajax.apply(webslinger, args));
		return this;
	};

	webslinger.prototype.event = webslinger.event;

	var remotePaneId = 0;
	webslinger.remotePane = function(id, path, subscribe, context) {
		OpenAjax.hub.subscribe(
			subscribe,
			function() {
				webslinger.event(
					path,
					context,
					function(result) {
						var container = jQuery("#" + id);
						OpenAjax.hub.publish("widget." + id + ".clear", container);
						container.empty().append(result).applyMutators();
						OpenAjax.hub.publish("widget." + id + ".fill", container);
					}
				);
			}
		);
		jQuery(
			function() {
				OpenAjax.hub.publish("widget." + id + ".fill", jQuery("#" + id));
			}
		);
	};

	webslinger.Latch = function(count, trigger) {
		var f = function() {
			count--;
			if (count == 0) trigger();
		};
		f.incr = function() {
			count++;
		};
		return f;
	};

	webslinger.url = {
		removeProtocol:	function(href) {
			return href.replace(/^([^:\/]+):\/\/([^:\/]+)((:[0-9]+))?/, "");
		},

		extractBase:	function(href) {
			href = webslinger.url.removeProtocol(href);
			if (href.charAt(href.length - 1) == "/") return href;
			var slash = href.lastIndexOf('/');
			return href.substring(0, slash + 1);
		}
	};

	OpenAjax.hub.subscribe(
		"page.refresh",
		function(name, data) {
			window.location = window.location;
		}
	);
	OpenAjax.hub.subscribe(
		"page.redirect",
		function(name, data) {
			window.location = data.location;
		}
	);
})();
