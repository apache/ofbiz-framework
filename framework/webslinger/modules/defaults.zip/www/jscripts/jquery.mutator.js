if (jQuery) (function() {
	var mutators = [];
	$.extend({
		addMutator: function(f) {
			mutators[mutators.length] = f;
		},
		applyMutators: function(ctx) {
			if (!ctx) ctx = document;
			for (var i in mutators) mutators[i](ctx);
		}
	});
	$.fn.applyMutators = function() {
		this.each(function() {
			$.applyMutators(this);
		});
		return this;
	};
	$(function() {
		$.applyMutators();
		$.addMutator = function(f) {
			mutators[mutators.length] = f;
			f(document);
		};
	});
})(jQuery);

