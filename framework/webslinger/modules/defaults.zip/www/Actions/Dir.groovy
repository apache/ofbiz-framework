import org.webslinger.servlet.MultipartFormUtil

def pathInfo = webslinger.pathInfo
if (!pathInfo) return null
def context = webslinger.context
def res = webslinger.resolvePath(webslinger.pathInfo)
webslinger.event("/WEB-INF/Events/DirHelper", "action", res)
def templates = res.resolveAll("$webslinger.themePath/Templates", [res.getAttribute("template", "Default")])
System.err.println("res=$res")
System.err.println("\ttemplate(" + res.getAttribute("template") + ")")
System.err.println("\ttemplate-def(" + res.getAttribute("template", "Default") + ")")
System.err.println("\ttemplates=$templates")

context.RequestResource = res
request.setAttribute("RequestResource", res)
if (res.exists()) {
    request.setAttribute("RequestTemplate", templates[0].servletPath)
    context.RequestTemplate = templates[0].servletPath
}
		def allParameters = MultipartFormUtil.parseRequestAsMap(request)
def parameters = MultipartFormUtil.filterOutStrings(allParameters)
if (request.getHeader("X-Requested-With") == "XMLHttpRequest" || parameters["isJson"] == "true") {
    response.setContentType("text/html")
    response.writer.write(webslinger.capturePath(res, templates))
} else {
    request.setAttribute("UseRequestTemplate", false)
    response.sendRedirect(webslinger.pathInfo)
}
return null
